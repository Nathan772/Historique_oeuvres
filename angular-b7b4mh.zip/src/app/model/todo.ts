export interface Todo {
  label: string;
  done: boolean;
}